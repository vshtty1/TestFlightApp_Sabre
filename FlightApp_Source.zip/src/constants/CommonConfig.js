const devConfig = {
    url:{
        API_URL : 'https://api-uat-ezycommerce.ezyflight.se'
    },
    accessTkn : "9d7d6eeb25cd6083e0df323a0fff258e59398a702fac09131275b6b1911e202d"
}

export const accessTkn = devConfig.accessTkn;

export const config = devConfig.url;