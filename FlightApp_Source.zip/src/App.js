import logo from './logo.svg';
import './App.css';
import FlightBook  from './components/FlightBook.js';
import { QueryClient, QueryClientProvider } from 'react-query'

const queryClient = new QueryClient()

function App() {
  return (
   <div className='form-bg'>
    <QueryClientProvider client={queryClient}>
    <FlightBook/>
    </QueryClientProvider>
   </div>    
  );
}

export default App;
