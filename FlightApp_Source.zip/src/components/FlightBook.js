import React, { useState, useEffect } from 'react';
import {
    FormControl, Button, Radio, RadioGroup, TextField, FormControlLabel, Autocomplete,
    Dialog, DialogTitle, DialogContentText, MenuItem, ListItemText, InputLabel, Select, OutlinedInput,
    ButtonGroup
} from '@mui/material';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { useQuery } from 'react-query'
import { config, accessTkn } from '../constants/CommonConfig'
import { FlightTakeoff, FlightLand } from '@mui/icons-material';

const fetchFlights = async () => {
    const requestOptions = {
        method: 'GET',
        headers: { 'Tenant-Identifier': `${accessTkn}` }
    }
    const res = await fetch(`${config.API_URL}/api/v1/Airport/OriginsWithConnections/en-us`, requestOptions);
    return res.json();
}

function ResultDialog(props) {
    const { onClose, open, isOneWay, ...stateObj } = props;

    const handleClose = () => {
        onClose(false);
    };

    return (
        <Dialog onClose={handleClose} open={open} fullWidth={true}>
            <DialogTitle className='dg-title'><strong>Trip Details</strong></DialogTitle>
            {isOneWay === 'true' && <DialogContentText id="result-text" className='dg-result'>
                <strong> {stateObj.from} </strong>{` to `} <strong>{stateObj.from}</strong><br></br>
                {stateObj.trvlrsCount} Travellers <br></br>
                <strong> Departure : </strong>{stateObj.departureDate}
            </DialogContentText>}

            {isOneWay !== 'true' && <DialogContentText id="result-text" className='dg-result'>
                <strong> {stateObj.from} </strong>{` to `} <strong>{stateObj.from}</strong><br></br>
                {stateObj.trvlrsCount} Travellers <br></br>
                <strong> Departure : </strong>{stateObj.departureDate} <br></br>
                <strong> Return : </strong>{stateObj.returnDate}
            </DialogContentText>}
        </Dialog>
    );
}


const FlightBook = () => {
    const [isOneWay, setIsOneWay] = useState('true');
    const [depDate, setDepDate] = useState(new Date());
    const [returnDate, setReturnDate] = useState(new Date());
    const { data, status } = useQuery('flights', fetchFlights)
    const [airportData, setAirportData] = useState([])
    const [connectionData, setConnectionData] = useState([])
    const [sourceAP, setSourceAP] = useState(null)
    const [destAP, setDestAP] = useState(null)
    const [openResult, setOpenResult] = useState(false);
    const [minDepDate, setMinDepDate] = useState(new Date());
    const [minRetDate, setMinRetDate] = useState(new Date());
    const [travellerTypes, setTravellerTypes] = useState([]);
    const [adultCount, setAdultCount] = useState(0);
    const [childrenCount, setChildrenCount] = useState(0);
    const [infantCount, setInfantCount] = useState(0);
    const [trvlrsCount, setTrvlrsCount] = useState(0);
    const travellerCategory = [
        'Adult',
        'Children',
        'Infant'
    ];

    useEffect(() => {
        fetchFlights();
    }, [])

    useEffect(() => {
        if (status !== 'loading' && data) {
            let airData = data.airports.map(x => x.name + ' - ' + x.code);
            setAirportData(airData);
        }
    }, [data])

    useEffect(() => {
        if (depDate !== undefined) {
            setMinRetDate(depDate)
        }
    }, [depDate])

    useEffect(() => {
        let value = travellerCategory;
        value = value.filter(tr => !(tr == 'Adult' && adultCount < 1) && !(tr == 'Children' && childrenCount < 1)
            && !(tr == 'Infant' && infantCount < 1));
        setTravellerTypes(
            value
        );
        if(adultCount<1 && infantCount>0){
            setInfantCount(0)
        }
        setTrvlrsCount(adultCount+childrenCount+infantCount)
    }, [adultCount, childrenCount, infantCount])

    const handleSourceChange = (source) => {
        let sourceData = data.airports.filter(x => x.name + ' - ' + x.code == source)
        let connections = sourceData[0].connections.map(x => x.name + ' - ' + x.code)
        setConnectionData(connections);
        setSourceAP(source);
        setDestAP(null);
    }

    const showSelectedText = () => {
        setOpenResult(true);
    }

    const handleResultClose = (event, reason) => {
        if (reason === 'clickaway') {
            return;
        }
        setOpenResult(false);
    };

    const handleTrIncrement = (trvlrType) => {
        switch (trvlrType) {
            case 'Adult':
                setAdultCount(adultCount + 1)
                break;
            case 'Children':
                setChildrenCount(childrenCount + 1)
                break;
            default:
                setInfantCount(infantCount + 1)
        }
    };

    const handleTrDecrement = (trvlrType) => {
        switch (trvlrType) {
            case 'Adult':
                setAdultCount(adultCount - 1)
                break;
            case 'Children':
                setChildrenCount(childrenCount - 1)
                break;
            default:
                setInfantCount(infantCount - 1)
        }
    };

    const fetchTrCounter = (trvlrType) => {
        switch (trvlrType) {
            case 'Adult':
                return adultCount;
            case 'Children':
                return childrenCount;
            default:
                return infantCount;
        }
    }

    const checkInfant =(trvlrType)=>{
        if(adultCount<1 && trvlrType==='Infant'){
            return true;
        }
        return false;
    }

    return (
        <React.Fragment>
            <form className='form-bg'>
                <h3>Book Domestic and International Flight Tickets</h3>
                <div className='container'>
                    <FormControl className='rdo-trip'>
                        <RadioGroup
                            row
                            aria-labelledby="demo-row-radio-buttons-group-label"
                            name="row-radio-buttons-group"
                            className='trip-container'
                            onChange={(e) => setIsOneWay(e.target.value)}
                            value={isOneWay}
                        >
                            <FormControlLabel value={'true'} control={<Radio />} label="One-way" />
                            <FormControlLabel value={'false'} control={<Radio />} label="Round-trip" />
                        </RadioGroup>
                    </FormControl>
                    <div name="flights-select">
                        <FlightTakeoff className='icn-flight' />
                        <FormControl className='cbo-flights'>
                            <Autocomplete
                                disablePortal
                                id="combo-box-start"
                                className='cbo-flights'
                                options={airportData}
                                sx={{ width: 310 }}
                                noOptionsText={"Enter From Airport"}
                                onChange={(e, air) => handleSourceChange(air)}
                                renderInput={(params) => <TextField {...params} label="Flying From" />}
                            />
                        </FormControl>
                        <FlightLand className='icn-flight' />
                        <FormControl className='cbo-flights'>
                            <Autocomplete
                                disablePortal
                                id="combo-box-dest"
                                className='cbo-flights'
                                options={connectionData}
                                value={destAP}
                                sx={{ width: 310 }}
                                onChange={(e, air) => setDestAP(air)}
                                renderInput={(params) => <TextField {...params} label="Flying To" />}
                            />
                        </FormControl>
                    </div>
                    <div name="date-select" className="date-select-container">
                        <LocalizationProvider dateAdapter={AdapterDateFns}>
                            <FormControl className='dt-select dt-departure'>
                                <DatePicker
                                    label="Departure"
                                    value={depDate}
                                    onChange={(newValue) => {
                                        setDepDate(newValue);
                                    }}
                                    minDate={minDepDate}
                                    renderInput={(params) => <TextField {...params} />}
                                />
                            </FormControl>
                            <FormControl className={`dt-select dt-return-${isOneWay}`}>
                                <DatePicker
                                    label="Return"
                                    value={returnDate}
                                    onChange={(newValue) => {
                                        setReturnDate(newValue);
                                    }}
                                    minDate={minRetDate}
                                    renderInput={(params) => <TextField {...params} />}
                                /></FormControl>
                        </LocalizationProvider>
                    </div>
                    <div name="traveller-select" className="traveller-select-container">
                        <FormControl sx={{ m: 1, width: 300 }} className='mnu-trvlrs'>
                            <InputLabel id="demo-multiple-checkbox-label">Travellers</InputLabel>
                            <Select
                                labelId="demo-multiple-checkbox-label"
                                id="demo-multiple-checkbox"
                                multiple
                                value={travellerTypes}
                                //onChange={handleTrChange}
                                input={<OutlinedInput label="Traveller" />}
                                renderValue={(selected) => selected.join(', ')}
                            // MenuProps={MenuProps}
                            >
                                {travellerCategory.map((cat) => (
                                    <MenuItem key={cat} value={cat}>
                                        <ButtonGroup size="small">
                                            <Button onClick={(e) => handleTrIncrement(cat)} className='btn-tr' disabled={checkInfant(cat)}>+</Button>
                                            <span className='btn-tr'>{fetchTrCounter(cat) > 0 && fetchTrCounter(cat)}</span>
                                            {fetchTrCounter(cat) && <Button onClick={(e) => handleTrDecrement(cat)} className='btn-tr'>-</Button>}
                                        </ButtonGroup>
                                        <ListItemText primary={cat} />
                                    </MenuItem>
                                ))}
                            </Select>
                        </FormControl>
                    </div>
                    <Button className='btn-search' variant="contained" onClick={showSelectedText}>Search</Button>

                    {openResult && <ResultDialog
                        open={openResult}
                        onClose={handleResultClose}
                        to={destAP}
                        from={sourceAP}
                        departureDate={depDate.toDateString()}
                        returnDate={returnDate.toDateString()}
                        isOneWay={isOneWay}
                        trvlrsCount={trvlrsCount}
                    />}
                </div>
            </form>
        </React.Fragment>
    )
}

export default FlightBook;